
Credits:

	Demo Images:
		Unsplash (unsplash.com)

	Icons:
		Font Awesome (fontawesome.io)

	Other:
		jQuery (jquery.com)
		Dropotron (github.com/ajlkn/jquery.dropotron)
		Responsive Tools (github.com/ajlkn/responsive-tools)